import os
import sys
from datetime import datetime
from typing import List, Dict, Any, Optional

import psycopg2
from psycopg2.extras import RealDictCursor

# Configurações de Conexão com o Banco de Dados
# Alinhado com o serviço 'postgres' configurado no docker-compose.yml
DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", 5432)),
    "dbname": os.getenv("DB_NAME", "industria40_db"),
    "user": os.getenv("DB_USER", "industria40_user"),
    "password": os.getenv("DB_PASSWORD", "industria40_pass")
}

def get_db_connection():
    """Cria e retorna uma conexão ativa com o banco PostgreSQL/TimescaleDB."""
    try:
        conn = psycopg2.connect(**DB_CONFIG, cursor_factory=RealDictCursor)
        return conn
    except psycopg2.Error as e:
        print(f"❌ Erro ao conectar ao banco de dados: {e}")
        return None

# ==============================================================================
# FUNÇÕES DE CONSULTA E OPERAÇÃO (EXEMPLOS PARA OS GRUPOS 1, 2, 3 E 4)
# ==============================================================================

def get_active_production_orders() -> List[Dict[str, Any]]:
    """
    Grupo 3 (MES) & Grupo 4 (Front-End):
    Retorna as Ordens de Produção ativas (IN_PROGRESS ou PENDING).
    """
    conn = get_db_connection()
    if not conn:
        return []
    
    try:
        with conn.cursor() as cursor:
            query = """
                SELECT id, order_number, target_quantity, produced_quantity, scrap_quantity, status, created_at
                FROM production_orders
                WHERE status IN ('PENDING', 'IN_PROGRESS')
                ORDER BY created_at DESC;
            """
            cursor.execute(query)
            return cursor.fetchall()
    finally:
        conn.close()

def get_latest_oee_metrics() -> Optional[Dict[str, Any]]:
    """
    Grupo 3 (MES) & Grupo 4 (Dashboard Web):
    Retorna a última medição de OEE registrada.
    """
    conn = get_db_connection()
    if not conn:
        return None
    
    try:
        with conn.cursor() as cursor:
            query = """
                SELECT timestamp_hour, availability, performance, quality, oee_score
                FROM oee_metrics_hourly
                ORDER BY timestamp_hour DESC
                LIMIT 1;
            """
            cursor.execute(query)
            return cursor.fetchone()
    finally:
        conn.close()

def insert_telemetry_event(device_id: str, machine_state: str, speed_rpm: float, raw_payload: str) -> bool:
    """
    Grupo 1 (IoT/CLP):
    Registra um evento de telemetria recebido via MQTT/WebSockets da botoeira Siemens ou CLP.
    """
    conn = get_db_connection()
    if not conn:
        return False
    
    try:
        with conn.cursor() as cursor:
            query = """
                INSERT INTO telemetry_logs (time, device_id, machine_state, speed_rpm, raw_payload)
                VALUES (NOW(), %s, %s, %s, %s);
            """
            cursor.execute(query, (device_id, machine_state, speed_rpm, raw_payload))
            conn.commit()
            print(f"✅ Telemetria registrada para o dispositivo '{device_id}' com estado '{machine_state}'.")
            return True
    except psycopg2.Error as e:
        print(f"❌ Erro ao registrar telemetria: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

def update_piece_status(qr_code: str, current_station: str, status: str) -> bool:
    """
    Grupo 2 (Cobot & Câmera) & Grupo 3 (Rastreabilidade):
    Atualiza o status e a localização da peça identificada pelo leitor de QR Code.
    """
    conn = get_db_connection()
    if not conn:
        return False
    
    try:
        with conn.cursor() as cursor:
            query = """
                UPDATE pieces_traceability
                SET current_station = %s, status = %s, updated_at = NOW()
                WHERE qr_code = %s;
            """
            cursor.execute(query, (current_station, status, qr_code))
            conn.commit()
            print(f"✅ Peça QR '{qr_code}' atualizada para a estação '{current_station}' ({status}).")
            return True
    except psycopg2.Error as e:
        print(f"❌ Erro ao atualizar rastreabilidade da peça: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

# ==============================================================================
# TESTE DE EXECUÇÃO LOCAL (DEMONSTRAÇÃO)
# ==============================================================================
if __name__ == "__main__":
    print("=" * 70)
    print("   TESTE DE CONEXÃO E OPERAÇÕES BD - APLICAÇÃO WEB INDÚSTRIA 4.0")
    print("=" * 70)

    # 1. Testar consulta de OEE
    oee = get_latest_oee_metrics()
    if oee:
        print(f"\n📊 Último OEE Registrado:")
        print(f"   - OEE Geral: {oee['oee_score'] * 100:.1f}%")
        print(f"   - Disponibilidade: {oee['availability'] * 100:.1f}%")
        print(f"   - Desempenho: {oee['performance'] * 100:.1f}%")
        print(f"   - Qualidade: {oee['quality'] * 100:.1f}%")

    # 2. Testar consulta de OPs
    orders = get_active_production_orders()
    print(f"\n📋 Ordens de Produção Ativas ({len(orders)}):")
    for ord_item in orders:
        print(f"   - OP #{ord_item['order_number']}: Status [{ord_item['status']}] - Progresso: {ord_item['produced_quantity']}/{ord_item['target_quantity']}")

    print("\n" + "=" * 70)
